﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NewDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = new Int32();
        }
    }
}
